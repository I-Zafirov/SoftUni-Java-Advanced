package T13DefiningClasses.exercise.E07Google2;

public class Main {
}
