package T13DefiningClasses.exercise.E09CatLady2;

public class Cat {
    String name;

    public String getName() {
        return name;
    }
}

